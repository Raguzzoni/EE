var searchData=
[
  ['con1_0',['con1',['../structspi1__configuration__t.html#a9388dc2dccf6bde0c3585ce4c2d5cf06',1,'spi1_configuration_t']]],
  ['current_5ffloor_1',['current_floor',['../main_8h.html#a681610bd79b47281c1ec96c7effc4db1',1,'main.h']]]
];
