var searchData=
[
  ['new_5frequest_0',['New_request',['../main_8c.html#a983cb6eb5b89c6cacac762022a8293a4',1,'New_request(int origin, int dest):&#160;main.c'],['../main_8h.html#a983cb6eb5b89c6cacac762022a8293a4',1,'New_request(int origin, int dest):&#160;main.c']]],
  ['next_5ffloor_1',['Next_floor',['../main_8c.html#ae0dac5621c210d3689efa6ae6bc57418',1,'Next_floor():&#160;main.c'],['../main_8h.html#ae0dac5621c210d3689efa6ae6bc57418',1,'Next_floor():&#160;main.c']]],
  ['next_5findex_2',['Next_index',['../main_8c.html#a4f4af1e051b7d9387360f0622805395b',1,'Next_index():&#160;main.c'],['../main_8h.html#a4f4af1e051b7d9387360f0622805395b',1,'Next_index():&#160;main.c']]]
];
