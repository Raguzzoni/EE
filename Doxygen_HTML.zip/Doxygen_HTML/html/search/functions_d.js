var searchData=
[
  ['update_5ftx_5fbuffer_0',['Update_tx_buffer',['../main_8c.html#a2bcfd92023f18bd5085216a1d80dde18',1,'Update_tx_buffer():&#160;main.c'],['../main_8h.html#a2bcfd92023f18bd5085216a1d80dde18',1,'Update_tx_buffer():&#160;main.c']]]
];
