var indexSectionsWithContent =
{
  0: "_acdefhilmnoprstuvw",
  1: "aesu",
  2: "_acdefimpst",
  3: "_acefimnoprstuw",
  4: "acdefhimnoprstuv",
  5: "a",
  6: "as",
  7: "cs",
  8: "_acdefhilmoprst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Estruturas de dados",
  2: "Arquivos",
  3: "Funções",
  4: "Variáveis",
  5: "Definições de Tipos",
  6: "Enumerações",
  7: "Enumeradores",
  8: "Definições e Macros"
};

