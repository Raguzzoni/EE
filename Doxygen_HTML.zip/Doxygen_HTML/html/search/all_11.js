var searchData=
[
  ['var_0',['var',['../main_8h.html#a99f8c41140e0c7e00d651595d2043229',1,'main.h']]],
  ['velocidade_1',['velocidade',['../main_8h.html#a41dafa618690233df0c2fdc4906e1343',1,'main.h']]],
  ['velocidade_5fstring_2',['velocidade_string',['../main_8h.html#a9d68e65d731091f75f582bba944c6193',1,'main.h']]],
  ['vvv_3',['VVV',['../structuart__var.html#ae05d20be0e2d5597892e967b65e90c15',1,'uart_var']]]
];
