var searchData=
[
  ['spi1_5fmodes_5ft_0',['spi1_modes_t',['../spi1_8h.html#a5534ab3c3850e4ce85ccbc35cbf841eb',1,'spi1.h']]]
];
