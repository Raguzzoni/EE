var searchData=
[
  ['spi1_5fclose_0',['SPI1_Close',['../spi1_8c.html#a8d97c5f4dff35a4940b7843207912659',1,'SPI1_Close(void):&#160;spi1.c'],['../spi1_8h.html#a8d97c5f4dff35a4940b7843207912659',1,'SPI1_Close(void):&#160;spi1.c']]],
  ['spi1_5fexchangeblock_1',['SPI1_ExchangeBlock',['../spi1_8c.html#a5ca38ee9c820ae41a0c2e751e9fbb9a2',1,'SPI1_ExchangeBlock(void *block, size_t blockSize):&#160;spi1.c'],['../spi1_8h.html#a5ca38ee9c820ae41a0c2e751e9fbb9a2',1,'SPI1_ExchangeBlock(void *block, size_t blockSize):&#160;spi1.c']]],
  ['spi1_5fexchangebyte_2',['SPI1_ExchangeByte',['../spi1_8c.html#ae07af4d41776972ec7a7691cec4ca0c4',1,'SPI1_ExchangeByte(uint8_t data):&#160;spi1.c'],['../spi1_8h.html#ae07af4d41776972ec7a7691cec4ca0c4',1,'SPI1_ExchangeByte(uint8_t data):&#160;spi1.c']]],
  ['spi1_5finitialize_3',['SPI1_Initialize',['../spi1_8c.html#a0607cad7a6b302950091fea719146a54',1,'SPI1_Initialize(void):&#160;spi1.c'],['../spi1_8h.html#a0607cad7a6b302950091fea719146a54',1,'SPI1_Initialize(void):&#160;spi1.c']]],
  ['spi1_5fopen_4',['SPI1_Open',['../spi1_8c.html#a75b793019e1495a9eb4c9d40f15fa9f2',1,'SPI1_Open(spi1_modes_t spi1UniqueConfiguration):&#160;spi1.c'],['../spi1_8h.html#a75b793019e1495a9eb4c9d40f15fa9f2',1,'SPI1_Open(spi1_modes_t spi1UniqueConfiguration):&#160;spi1.c']]],
  ['spi1_5freadblock_5',['SPI1_ReadBlock',['../spi1_8c.html#a0d9ea49076af2ddeec759efe4fadc70a',1,'SPI1_ReadBlock(void *block, size_t blockSize):&#160;spi1.c'],['../spi1_8h.html#a0d9ea49076af2ddeec759efe4fadc70a',1,'SPI1_ReadBlock(void *block, size_t blockSize):&#160;spi1.c']]],
  ['spi1_5freadbyte_6',['SPI1_ReadByte',['../spi1_8c.html#abbc9771abeebcf4c26bcaf627666ffc2',1,'SPI1_ReadByte(void):&#160;spi1.c'],['../spi1_8h.html#abbc9771abeebcf4c26bcaf627666ffc2',1,'SPI1_ReadByte(void):&#160;spi1.c']]],
  ['spi1_5fwriteblock_7',['SPI1_WriteBlock',['../spi1_8c.html#af8e73470ce8af7f2ce8fd04990162caf',1,'SPI1_WriteBlock(void *block, size_t blockSize):&#160;spi1.c'],['../spi1_8h.html#af8e73470ce8af7f2ce8fd04990162caf',1,'SPI1_WriteBlock(void *block, size_t blockSize):&#160;spi1.c']]],
  ['spi1_5fwritebyte_8',['SPI1_WriteByte',['../spi1_8c.html#af04c82a7fa9d0a7595b69e2808d5c837',1,'SPI1_WriteByte(uint8_t byte):&#160;spi1.c'],['../spi1_8h.html#af04c82a7fa9d0a7595b69e2808d5c837',1,'SPI1_WriteByte(uint8_t byte):&#160;spi1.c']]],
  ['start_9',['Start',['../main_8c.html#a07aaf1227e4d645f15e0a964f54ef291',1,'Start():&#160;main.c'],['../main_8h.html#a07aaf1227e4d645f15e0a964f54ef291',1,'Start():&#160;main.c']]],
  ['system_5finitialize_10',['SYSTEM_Initialize',['../mcc_8c.html#a5e8391114a0cf91ac20002be25e3d352',1,'SYSTEM_Initialize(void):&#160;mcc.c'],['../mcc_8h.html#a5e8391114a0cf91ac20002be25e3d352',1,'SYSTEM_Initialize(void):&#160;mcc.c']]]
];
