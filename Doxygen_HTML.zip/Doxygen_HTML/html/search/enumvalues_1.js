var searchData=
[
  ['spi1_5fdefault_0',['SPI1_DEFAULT',['../spi1_8h.html#a5534ab3c3850e4ce85ccbc35cbf841eba70443a1da9c21e88400c09d62c228365',1,'spi1.h']]]
];
