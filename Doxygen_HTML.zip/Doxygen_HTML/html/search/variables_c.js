var searchData=
[
  ['stat_0',['stat',['../structspi1__configuration__t.html#a3e0101ab4f197aedba71e5ed14c6bf20',1,'spi1_configuration_t']]],
  ['status_1',['status',['../unioneusart__status__t.html#ade818037fd6c985038ff29656089758d',1,'eusart_status_t']]],
  ['stop_5f2s_2',['stop_2s',['../main_8h.html#a8fde7b2c07a5b9f0aa726f51e78c9701',1,'main.h']]]
];
