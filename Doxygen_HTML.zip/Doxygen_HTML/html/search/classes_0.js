var searchData=
[
  ['adc_5fsync_5fdouble_5fresult_5ft_0',['adc_sync_double_result_t',['../structadc__sync__double__result__t.html',1,'']]]
];
