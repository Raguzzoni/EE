var searchData=
[
  ['spi1_5fconfiguration_5ft_0',['spi1_configuration_t',['../structspi1__configuration__t.html',1,'']]]
];
