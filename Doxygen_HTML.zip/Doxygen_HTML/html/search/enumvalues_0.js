var searchData=
[
  ['channel_5fan2_0',['channel_AN2',['../adc_8h.html#aafc4060027875f8fe46242b0656d7814a8753c2db520e7b9b37e31d601ea9abe0',1,'adc.h']]],
  ['channel_5fdac_1',['channel_DAC',['../adc_8h.html#aafc4060027875f8fe46242b0656d7814a1803faf8301d5aa442661259085ccd07',1,'adc.h']]],
  ['channel_5ffvr_2',['channel_FVR',['../adc_8h.html#aafc4060027875f8fe46242b0656d7814aeffb75f5407ff8887f04e694210e231a',1,'adc.h']]],
  ['channel_5ftemp_3',['channel_Temp',['../adc_8h.html#aafc4060027875f8fe46242b0656d7814ab7dd29210090fd58211f210334462325',1,'adc.h']]]
];
