var searchData=
[
  ['o_0',['O',['../structuart__var.html#a0f56e59fe2670fefd06fe2884848022e',1,'uart_var']]],
  ['oerr_1',['oerr',['../unioneusart__status__t.html#a8e7505a43bf03e13302937d789ce63ae',1,'eusart_status_t']]],
  ['operation_2',['operation',['../structspi1__configuration__t.html#a97d486d6926f9137837e1d8ecf0bbfdd',1,'spi1_configuration_t']]]
];
