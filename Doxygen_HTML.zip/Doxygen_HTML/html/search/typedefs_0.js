var searchData=
[
  ['adc_5fresult_5ft_0',['adc_result_t',['../adc_8h.html#ac5362ae65441a5027b4b9b1bf1b573aa',1,'adc.h']]]
];
