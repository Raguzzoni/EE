var searchData=
[
  ['uart_5fvar_0',['uart_var',['../structuart__var.html',1,'']]]
];
