var searchData=
[
  ['fvr_5finitialize_0',['FVR_Initialize',['../fvr_8c.html#a3ed4c32289cb98c4b78395c766f1e740',1,'FVR_Initialize(void):&#160;fvr.c'],['../fvr_8h.html#a3ed4c32289cb98c4b78395c766f1e740',1,'FVR_Initialize(void):&#160;fvr.c']]],
  ['fvr_5fisoutputready_1',['FVR_IsOutputReady',['../fvr_8c.html#ace1bf2607c0bca57b9c11e742c62afc0',1,'FVR_IsOutputReady(void):&#160;fvr.c'],['../fvr_8h.html#ace1bf2607c0bca57b9c11e742c62afc0',1,'FVR_IsOutputReady(void):&#160;fvr.c']]]
];
