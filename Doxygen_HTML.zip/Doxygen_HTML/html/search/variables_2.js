var searchData=
[
  ['d_0',['D',['../structuart__var.html#a35ab39081e6835946f3edf534a685718',1,'uart_var']]]
];
