var searchData=
[
  ['a_0',['A',['../structuart__var.html#adb940abb01ff1c7c8ab030453ae39bce',1,'uart_var']]],
  ['adc_5finterrupthandler_1',['ADC_InterruptHandler',['../adc_8c.html#afd07ad436449919718eb6b73351335f6',1,'ADC_InterruptHandler:&#160;adc.c'],['../adc_8h.html#afd07ad436449919718eb6b73351335f6',1,'ADC_InterruptHandler:&#160;adc.c']]],
  ['adcresult1_2',['adcResult1',['../structadc__sync__double__result__t.html#a4a123c2396a2013b27d8d4cea6341980',1,'adc_sync_double_result_t']]],
  ['adcresult2_3',['adcResult2',['../structadc__sync__double__result__t.html#aedc782211c19c3e736d4b81b63d86d04',1,'adc_sync_double_result_t']]],
  ['add_4',['add',['../structspi1__configuration__t.html#a8cd82571c461a092b7e41ef838c6082c',1,'spi1_configuration_t']]]
];
