var searchData=
[
  ['reserved_0',['reserved',['../unioneusart__status__t.html#a6a6017ea077b575677a11d733ec137a3',1,'eusart_status_t']]],
  ['route_1',['route',['../main_8h.html#a1f08af246b7ba2a7368fefbba1ba49fa',1,'main.h']]]
];
