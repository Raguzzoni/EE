var searchData=
[
  ['main_0',['main',['../main_8c.html#acdef7a1fd863a6d3770c1268cb06add3',1,'main.c']]],
  ['matrix_5fupdate_5fdir_1',['Matrix_update_dir',['../main_8c.html#aa94b73a514d51255bd61fcc0da5d023b',1,'Matrix_update_dir():&#160;main.c'],['../main_8h.html#aa94b73a514d51255bd61fcc0da5d023b',1,'Matrix_update_dir():&#160;main.c']]],
  ['matrix_5fupdate_5ffloor_2',['Matrix_update_floor',['../main_8c.html#a99966a9ce924300797a1ad8a8617a188',1,'Matrix_update_floor(uint8_t display_floor):&#160;main.c'],['../main_8h.html#a99966a9ce924300797a1ad8a8617a188',1,'Matrix_update_floor(uint8_t display_floor):&#160;main.c']]],
  ['motor_5fturn_5foff_3',['Motor_Turn_Off',['../main_8c.html#a5645fd110b359011b5be89015207f955',1,'Motor_Turn_Off():&#160;main.c'],['../main_8h.html#a5645fd110b359011b5be89015207f955',1,'Motor_Turn_Off():&#160;main.c']]],
  ['motor_5fturn_5fon_4',['Motor_Turn_On',['../main_8c.html#af8c6e550b7c7ace1a0c8e3314f180522',1,'Motor_Turn_On():&#160;main.c'],['../main_8h.html#af8c6e550b7c7ace1a0c8e3314f180522',1,'Motor_Turn_On():&#160;main.c']]]
];
