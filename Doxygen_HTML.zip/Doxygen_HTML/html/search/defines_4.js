var searchData=
[
  ['eusart_5fdataready_0',['EUSART_DataReady',['../eusart_8h.html#accdd7cd6215305b8b1bc2b3698621bc0',1,'eusart.h']]],
  ['eusart_5frx_5fbuffer_5fsize_1',['EUSART_RX_BUFFER_SIZE',['../eusart_8c.html#a0b6e850d4781b01f5d53665293956271',1,'eusart.c']]],
  ['eusart_5ftx_5fbuffer_5fsize_2',['EUSART_TX_BUFFER_SIZE',['../eusart_8c.html#a09ddd159876c86ef8111c5940da77075',1,'eusart.c']]]
];
