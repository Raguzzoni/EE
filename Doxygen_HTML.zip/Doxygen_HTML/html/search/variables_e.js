var searchData=
[
  ['uart_5fread_5fbuffer_0',['uart_read_buffer',['../main_8h.html#a54f978752e75e19a3431e10a20a12de1',1,'main.h']]],
  ['uart_5fread_5fbuffer_5fcount_1',['uart_read_buffer_count',['../main_8h.html#a94b0619a3249bc777a0c9c5ef50ce7c2',1,'main.h']]],
  ['uart_5fwrite_5fbuffer_2',['uart_write_buffer',['../main_8h.html#aba2bc4b8b3ce9c5652de35ace36369f6',1,'main.h']]]
];
