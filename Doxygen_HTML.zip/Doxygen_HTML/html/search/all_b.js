var searchData=
[
  ['o_0',['O',['../structuart__var.html#a0f56e59fe2670fefd06fe2884848022e',1,'uart_var']]],
  ['oerr_1',['oerr',['../unioneusart__status__t.html#a8e7505a43bf03e13302937d789ce63ae',1,'eusart_status_t']]],
  ['operation_2',['operation',['../structspi1__configuration__t.html#a97d486d6926f9137837e1d8ecf0bbfdd',1,'spi1_configuration_t']]],
  ['oscillator_5finitialize_3',['OSCILLATOR_Initialize',['../mcc_8c.html#a4777dd92514a7e4ef803f9e869006f5d',1,'OSCILLATOR_Initialize(void):&#160;mcc.c'],['../mcc_8h.html#a4777dd92514a7e4ef803f9e869006f5d',1,'OSCILLATOR_Initialize(void):&#160;mcc.c']]],
  ['output_4',['OUTPUT',['../pin__manager_8h.html#a61a3c9a18380aafb6e430e79bf596557',1,'pin_manager.h']]]
];
